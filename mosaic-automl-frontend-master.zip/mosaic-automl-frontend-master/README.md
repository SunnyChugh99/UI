# mosaic-automl-frontend

This service is used to manage all the UI activity of auto ml framework.
