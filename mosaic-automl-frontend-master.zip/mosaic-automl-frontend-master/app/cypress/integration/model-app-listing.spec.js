const modelName = 'PredictMarket';
const modelDescription = 'Predictsmarkettrend';
const flavourType = 'sklearn';

describe('Models & Apps listings', () => {
  before(() => {
    cy.visit('/');
  });

  beforeEach(() => {
    cy.fixture('models').as('models');
    cy.fixture('apps').as('apps');

    cy.server();

    cy.route('GET', '/registry/api/v1/ml-model?type=model', '@models');
    cy.route('GET', '/registry/api/v1/ml-model?type=app', '@apps');
    cy.route('POST', '/registry/api/v1/application/register').as('registerApp');
    cy.route(
      'POST',
      '/registry/api/v1/model/register/tarball'
        .concat('?name=')
        .concat(modelName)
        .concat('&description=')
        .concat(modelDescription)
        .concat('&flavour=')
        .concat(flavourType),
    ).as('registerModel');
  });

  it('models: test all & deployed filters', () => {
    cy.findByRole('tab', { name: /models/i }).click();
    cy.verifyModelAppListings();
  });

  it('test register model', () => {
    cy.findByRole('tab', { name: /models/i }).click();

    cy.findByRole('button', { name: /register/i }).click();
    cy.findByText('Register Model').should('be.visible');

    cy.findByRole('textbox', { name: /model name/i }).type(modelName);
    cy.findByRole('textbox', { name: /model description/i }).type(modelDescription);
    cy.findByRole('button', { name: /select flavour sklearn/i })
      .click()
      .get(`li[data-value=${flavourType}]`)
      .click();
    cy.findByRole('textbox', { name: /pre script/i }).type('mkdir abcd');
    cy.findByRole('button', { name: /upload/i }).within(() => {
      cy.get('input[type=file]').attachFile('projects.tar.gz');
    });

    cy.findByRole('button', { name: /cancel/i })
      .next()
      .click();

    cy.wait('@registerModel').then((xhr) => {});
  });

  it('apps: test all & deployed filters', () => {
    cy.findByRole('tab', { name: /applications/i }).click();
    cy.verifyModelAppListings();
  });

  it('test register app', () => {
    cy.findByRole('tab', { name: /applications/i }).click();

    cy.findByRole('button', { name: /register/i }).click();
    cy.findByText('Register Application').should('be.visible');

    cy.findByRole('textbox', { name: /application name/i }).type('MosaicAi');
    cy.findByRole('textbox', { name: /application description/i }).type('Ai Predict');
    cy.findByRole('button', { name: /select docker image python/i })
      .click()
      .get('li[data-value=Java]')
      .click();
    cy.findByRole('textbox', { name: /enter port number/i }).type(8085);
    cy.findByRole('button', { name: /upload/i }).within(() => {
      cy.get('input[type=file]').attachFile('java-app.zip');
    });

    cy.findByRole('button', { name: /cancel/i })
      .next()
      .click();

    cy.wait('@registerApp').should('have.property', 'status', 200);
  });
});
