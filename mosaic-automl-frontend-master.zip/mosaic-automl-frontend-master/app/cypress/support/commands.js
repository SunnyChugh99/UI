Cypress.Commands.add('verifyModelAppListings', () => {
  cy.findAllByText('Not Deployed').should('have.length.gt', 0);
  cy.findAllByText('Deployed').should('have.length.gt', 0);

  cy.findByRole('button', { name: /filter/i })
    .click()
    .get('li[data-value=Deployed]')
    .click();

  cy.findAllByText('Not Deployed').should('have.length', 0);

  cy.findAllByRole('button', { name: /deployed/i })
    .click()
    .get('li[data-value=All]')
    .click();

  cy.findAllByText('Not Deployed').should('have.length.gt', 0);
  cy.findAllByText('Deployed').should('have.length.gt', 0);
});

// -- This is a child command --
// Cypress.Commands.add("drag", { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add("dismiss", { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite("visit", (originalFn, url, options) => { ... })
