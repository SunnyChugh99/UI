import React, { useEffect } from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter } from 'react-router-dom';
import request from './lib/requestUtil';
import ErrorBoundary from 'ai-ui-components-react/build/ErrorBoundary';
import { AppRoutes } from './routes';
import { useTheme } from '@material-ui/core/styles';

import { theme as oldTheme } from 'ai-ui-components-react/build/theme';
import { theme as newTheme } from 'ai-ui-components-react/build/newTheme';
import { createTheme, ThemeProvider } from '@material-ui/core/styles';

import 'ai-ui-components-react/build/index.css';
import 'react-reflex/styles.css';
import './styles.scss';
import config from './config.json';
import RouteWrapper from 'ai-ui-components-react/build/RouteWrapper';
import { endPoints } from './lib/endpoints';

const oldThemeConfigMl = createTheme(oldTheme);

if (window.parent.appName === 'catalog') {
  newTheme.palette.primary.main = '#ffb400';
}

const newThemeConfigMl = createTheme(newTheme);

if (process.env.NODE_ENV === 'development') {
  sessionStorage.setItem('hasValidLicense', true);

  const user = {
    username: 'sam.david@lntinfotech.com',
    email: 'sam.david@lntinfotech.com',
    firstName: 'Sam',
    lastName: 'David',
    roleDetails: [
      {
        name: 'MOSAIC_ETL_OPERATOR',
        description: 'This role will provide read only access to mosiac dicision features',
        actions: {
          PROJECT: ['VIEW'],
          'DAG-BACKEND_ACL': ['view', 'Execute', 'modify'],
          scheduler_acl: ['VIEW', 'RUN', 'KILL', 'PUASE', 'RESTART', 'RESUME'],
          MONITOR: ['view'],
          DAG_FRONTEND_ACL: ['view', 'Execute', 'modify'],
          SCHEDULER: ['view', 'execute'],
          'MOSAIC-CONSOLE-BACKEND_ACL': ['VIEW'],
          DAG: ['view', 'execute', 'modify'],
          monitor_acl: ['VIEW', 'RUN', 'KILL'],
        },
      },
      {
        name: 'AI-LOGISTICS-OPERATOR',
        description: null,
        actions: { '/notebooks/api': ['view'], '/registry/api': ['view'] },
      },
      { name: 'admin', description: 'Admin Role', actions: {} },
      { name: 'business_user', description: null, actions: {} },
      { name: 'data-science-operator', description: null, actions: {} },
      {
        name: 'MOSAIC_ETL_DEVELOPER',
        description: 'This role will provide all access to mosaic decision features.',
        actions: {
          PROJECT: ['view', 'add', 'modify', 'delete', 'grant', 'revoke'],
          'DAG-BACKEND_ACL': ['View', 'Modify', 'Execute', 'delete'],
          scheduler_acl: [
            'VIEW',
            'DELETE',
            'MODIFY',
            'RUN',
            'CREATE',
            'PAUSE',
            'RESUME',
            'KILL',
            'RESTART',
          ],
          MONITOR: ['view', 'kill', 'pause', 'resume', 'restart'],
          'MOSAIC-CONSOLE-BACKEND_ACL': ['VIEW', 'ADD', 'MODIFY'],
          DAG: ['view', 'execute', 'delete', 'add', 'modify'],
          'DAG-FRONTEND_ACL': ['View', 'Modify', 'Execute', 'add'],
          monitor_acl: ['VIEW', 'MODIFY', 'RUN', 'DELETE', 'KILL'],
          USERMGM_ACL: ['View', 'Modify', 'Sync_users', 'Remove_users'],
          Catalog_Manager: [
            'publish',
            'users',
            'scheduler',
            'monitor',
            'runconfig',
            'audit',
            'expressions',
            'global',
            'licensing',
          ],
          DISCOVER_API_ACL: ['view', 'add', 'delete'],
          SCHEDULER: ['view', 'add', 'modify', 'execute', 'delete'],
        },
      },
      { name: 'uma_authorization', actions: {} },
      {
        name: 'AI-LOGISTICS-READ-ONLY-USER',
        description: null,
        actions: { '/notebooks/api': ['view'], '/registry/api': ['view'] },
      },
      {
        name: 'data-science-developer',
        description: null,
        actions: {
          registry: ['view', 'modify'],
          '/scheduler/api': ['view', 'modify'],
          '/notebooks/api': ['view', 'modify'],
        },
      },
      {
        name: 'MOSAIC_DECISION_MANAGE_CONNECTIONS',
        description: 'Can view/edit/add/delete connections from manager persona',
        actions: {},
      },
      {
        name: 'Dummy_role',
        description: 'This roll will provide access to catalog and publish and user management ',
        actions: {
          'pat-admin': ['new', 'old'],
          DISCOVERROLE: ['view', 'mode'],
          DISCOVER_API_ACL: ['view', 'read'],
        },
      },
      {
        name: 'MOSAIC_ETL_READ_ONLY_USER',
        description: 'This roll will provide read only access to mosaic decision features.',
        actions: {
          PROJECT: ['view'],
          'DAG-BACKEND_ACL': ['View'],
          scheduler_acl: ['VIEW'],
          MONITOR: ['view'],
          SCHEDULER: ['view'],
          'MOSAIC-CONSOLE-BACKEND_ACL': ['VIEW'],
          DAG: ['view'],
          'DAG-FRONTEND_ACL': ['View'],
          monitor_acl: ['VIEW'],
        },
      },
      { name: 'manager', description: null, actions: {} },
      {
        name: 'AI-LOGISTICS-DEVELOPER',
        description: null,
        actions: {
          '/auto-ml/api': ['view', 'modify'],
          '/registry/api': ['view', 'modify'],
          '/notebooks/api': ['view', 'modify'],
        },
      },
      { name: 'super_user', description: null, actions: {} },
      {
        name: 'MOSAIC_DECISIONS_POWER_DEVELOPER',
        description:
          'Can create new project & Edit with all rights on DAG, Notebooks, Models, Querying & Scheduling\nCan be granted with “Owner”, “Contributor” & “Reviewer” privileges on other projects',
        actions: {
          MONITOR_ACL: ['VIEW', 'MODIFY', 'RUN', 'DELETE', 'KILL'],
          'DAG-BACKEND_ACL': ['View', 'Modify', 'Execute'],
          'DAG-FRONTEND_ACL': ['View', 'Modify', 'Execute'],
        },
      },
      {
        name: 'Data_Citizen_Reader',
        description: 'This role will provide access to discover, Library , consume.',
        actions: {
          USERMGM_ACL: ['View'],
          Mosaic_Catalog: ['discover'],
          Catalog_Manager: [],
          DISCOVER_API_ACL: [],
        },
      },
      {
        name: 'MOSAIC_SCHEDULER',
        description: 'This role will provide access to scheduler features.',
        actions: { scheduler_acl: ['CREATE', 'VIEW', 'MODIFY', 'RUN', 'DELETE'] },
      },
    ],
    onlineSessions: null,
    groups: ['mosaic', 'mosaic-aiops'],
    subGroups: ['catalog_data_citizen', 'mosaic-ai-logistics', 'mosaic-lens', 'mosaic-notebooks'],
  };

  sessionStorage.setItem('userDetails', JSON.stringify(user));
  sessionStorage.setItem('email', user.email);
  sessionStorage.setItem('userid', user.username);
  sessionStorage.setItem('roles', JSON.stringify(user.roleDetails));

  window.config = config;
}

sessionStorage.setItem('exploreModelTab', '0');
sessionStorage.setItem('invocationTab', '0');

if (document.getElementById('app-loader-mosaic')) {
  document.getElementById('app-loader-mosaic').style.display = 'none';
}

if (document.getElementById('app-loader')) {
  document.getElementById('app-loader').style.display = 'none';
}

document.body.style.backgroundColor = window.parent.appName === 'catalog' ? '#f5f5f5' : '#d3d3d3';

const getConfigs = () => {
  return request('/ai/ml/config.json')
    .then((response) => {
      if (response && typeof response === 'object' && response.projectTitle) {
        window.config = response;
        document.title = response.projectTitle;
      }
    })
    .catch((error) => {});
};

const AppRoutesWrapper = () => {
  const theme = useTheme();

  useEffect(() => {
    document.body.className =
      sessionStorage.getItem('activeTheme') === 'new'
        ? 'new-catalog-theme-progres'
        : 'old-theme-progress';

    document.documentElement.setAttribute(
      'style',
      `--typography-font-family: ${theme.typography.fontFamily}`,
    );
  }, [theme]);

  return <AppRoutes />;
};

getConfigs().then(() => {
  ReactDOM.render(
    <BrowserRouter basename="/ai/ml">
      <ThemeProvider
        theme={
          window.config.useNewTheme || sessionStorage.getItem('activeTheme') === 'new'
            ? newThemeConfigMl
            : oldThemeConfigMl
        }
      >
        <ErrorBoundary baseUrl={window.config.baseUrl}>
          {window.parent.hideWrapper ? (
            <AppRoutesWrapper />
          ) : (
            <RouteWrapper
              configs={window.config}
              projectDetailsUrl={endPoints.mosaic.list}
              subscriberUrl={endPoints.subscription.subscriber}
              subscriptionRenewUrl={endPoints.subscription.renew}
              subscriptionWelcomeEmail={endPoints.subscription.welcomeEmail}
            >
              <AppRoutes />
            </RouteWrapper>
          )}
        </ErrorBoundary>
      </ThemeProvider>
    </BrowserRouter>,
    document.getElementById('app'),
  );
});
