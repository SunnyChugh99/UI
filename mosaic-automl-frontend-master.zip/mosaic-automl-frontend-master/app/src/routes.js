import React, { Suspense } from 'react';
import { Switch, Route, Redirect, useRouteMatch } from 'react-router-dom';

const ExperimentListing = React.lazy(() =>
  import('./lib/containers/experimentListing/ExperimentListing'),
);

const ExploreModel = React.lazy(() =>
  import('./lib/containers/exploreModelContainer/ExploreModel'),
);

const ModelsLandingPage = React.lazy(() =>
  import('./lib/containers/modelsLandingPage/ModelsLandingPage'),
);

const BuildTimeMetrics = React.lazy(() =>
  import('./lib/components/exploreModelComponent/VersionTab/BuildTimeMetrics'),
);

const InvocationMetrics = React.lazy(() =>
  import('./lib/components/exploreModelComponent/VersionTab/InvocationMetrics'),
);

const InvocationRequestView = React.lazy(() =>
  import(
    './lib/components/exploreModelComponent/VersionTab/InvocationMetricsRequest/InvocationRequestView'
  ),
);

const ModelExplainAi = React.lazy(() => import('./lib/containers/modelExplainAi/ModelExplainAi'));

const AutomlLandingPage = React.lazy(() =>
  import('./lib/containers/automlLandingPage/AutomlLandingPage'),
);

const ExploreExperiment = React.lazy(() =>
  import('./lib/containers/exploreExperiment/ExploreExperiment'),
);

const ExploreModelCloud = React.lazy(() =>
  import('./lib/containers/exploreModelContainer/ExploreModelCloud'),
);

const KydDataDrift = React.lazy(() => import('./lib/containers/kydDataDrift/KydDataDrift'));

export const AppRoutes = () => (
  <Suspense fallback={<div />}>
    <Route path="/:projectId">
      <Switch>
        <Route path="/:projectId/models" component={ModelRoutes} />
        <Route path="/:projectId/automl" component={AutoMlRoutes} />
      </Switch>
    </Route>
  </Suspense>
);

const ModelRoutes = () => {
  const { path, url } = useRouteMatch();

  return (
    <Switch>
      <Route exact path={`${path}`} component={ModelsLandingPage} />
      <Route exact path={`${path}/explore/:modelId`} component={ExploreModel} />
      <Route exact path={`${path}/overview/:modelId/:projectId`} component={ExploreModelCloud} />
      <Route exact path={`${path}/explore/btm/:versionId`} component={BuildTimeMetrics} />
      <Route exact path={`${path}/explore/invocation/:versionId`} component={InvocationMetrics} />
      <Route
        exact
        path={`${path}/explore/invocationRequests/:versionId`}
        component={InvocationRequestView}
      />
      <Route
        exact
        path={`${path}/explore/explain/:modelId/:versionId`}
        render={(props) => (
          <Redirect
            to={`${url}/modelexplainai/${props.match.params.modelId}/${props.match.params.versionId}`}
          />
        )}
      />
      <Route
        exact
        path={`${path}/explore/kyddatadrift/:modelId/:versionId`}
        render={(props) => (
          <Redirect
            to={`${url}/kyddatadrift/${props.match.params.modelId}/${props.match.params.versionId}`}
          />
        )}
      />
      <Route exact path={`${path}/modelexplainai/:modelId`} component={ModelExplainAi} />
      <Route exact path={`${path}/modelexplainai/:modelId/:versionId`} component={ModelExplainAi} />
      <Route exact path={`${path}/kyddatadrift/:modelId/:versionId`} component={KydDataDrift} />
      <Route
        path={'*'}
        render={() => {
          window.location = window.config.baseUrl;
        }}
      />
    </Switch>
  );
};

const AutoMlRoutes = () => {
  const { path, url } = useRouteMatch();

  return (
    <Switch>
      <Route exact path={`${path}/newlist`} component={ExperimentListing} />
      <Route
        exact
        path={`${path}/landingpage`}
        render={(props) => {
          return <Redirect to={`${url}/createexperiment`} />;
        }}
      />
      <Route exact path={`${path}/createexperiment`} component={AutomlLandingPage} />
      <Route exact path={`${path}/exploreExperiment/:experimentId`} component={ExploreExperiment} />
      <Redirect to={`${url}/createexperiment`} />
    </Switch>
  );
};
