const { createProxyMiddleware } = require('http-proxy-middleware');

const proxyURL = [
  '/mosaic-console-backend',
  '/usermgm',
  '/auto-ml/api/',
  '/discover/api/',
  '/license-service',
  '/scheduler/api',
  '/registry/api/',
  '/monitor/logaggregator/',
  '/mosaic-socketio/socket.io',
  '/notebooks/api',
  '/automl/api',
  '/input-parameter/secured',
  '/vcs/api',
  '/metering',
  '/lens-manageconsole',
  '/lens-socket',
];

module.exports = function (app) {
  proxyURL.forEach((URL) => {
    app.use(
      createProxyMiddleware(URL, {
        target: 'http://refract.devproxy.fosfor.com',
        changeOrigin: true,
        secure: false,
      }),
    );
  });
};
