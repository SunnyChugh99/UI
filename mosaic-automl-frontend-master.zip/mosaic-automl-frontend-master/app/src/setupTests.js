// jest-dom adds custom jest matchers for asserting on DOM nodes.
// allows you to do things like:
// expect(element).toHaveTextContent(/react/i)
// learn more: https://github.com/testing-library/jest-dom
import '@testing-library/jest-dom';
import MutationObserver from '@sheerun/mutationobserver-shim';
import config from './config.json';

class ResizeObserver {
  observe() {}
  disconnect() {}
}

window.ResizeObserver = ResizeObserver;
window.MutationObserver = MutationObserver;
window.config = config;

/**
 * fix: `matchMedia` not present, legacy browsers require a polyfill
 */
global.matchMedia =
  global.matchMedia ||
  function () {
    return {
      matches: false,
      addListener: function () {},
      removeListener: function () {},
    };
  };

jest.setTimeout(10000);
