import os
import sys
import argparse
import subprocess


class MosaicDockerBuild(object):
    def __init__(self,
                 docker_file_path: str = None,
                 file_names_mapping: dict = None):
        """
        Initializes MosaicDockerBuild For Retrieving Tags

        :param docker_file_path: path of the folder containing images with parameter - foo/bar/{}.py
        :param file_names_mapping: dict[filename: (filename, cpu_variable_name, gpu_variable_name), ..]
        """
        self.default_location = "notebooks-api/src/notebooks_api/docker_image/image_information/{}.py"

        self.docker_file_path = docker_file_path or self.default_location

        self.file_names = file_names_mapping or {}

        self.parser = argparse.ArgumentParser(description='It will Build docker Images and push to registry')
        self.parser.add_argument('--which', help='which docker image to build ')

    def build(self):
        args = self.parser.parse_args()
        print(f"Select Build Type ---> {args.which}")

        try:
            if args.which.lower() == "frontend":
                self.build_frontend()
            else:
                image_file_name, cpu_tag_name, gpu_tag_name = self.file_names[args.which]
                self.build_tags(image_file_name, cpu_tag_name, gpu_tag_name)
        except Exception as e:
            print("No Matching Build Strategy Found - Please check if you are using correct value in Which argument.")
            raise
    
    @staticmethod
    def build_frontend():
        docker_file = "app.version"
        docker_file_content = open(docker_file, "r").read().splitlines()
        
        with open("build_tags.env", 'w') as output:
            output.write('export FRONTEND_TAG="' + str(docker_file_content[0]).strip() + '" \n')

    def build_tags(self,
                   file_name: str,
                   cpu_tag_name: str,
                   gpu_tag_name: str):
        CPU_TAG = ""
        GPU_TAG = ""

        docker_file = self.docker_file_path.format(file_name)
        docker_file_content = open(docker_file, "r").read().splitlines()

        for each_line in docker_file_content:
            if cpu_tag_name in each_line and "=" in each_line:
                CPU_TAG = each_line.strip().replace(" ", "")

            if gpu_tag_name in each_line and "=" in each_line:
                GPU_TAG = each_line.strip().replace(" ", "")

        with open("build_tags.env", 'w') as output:
            output.write("export " + str(CPU_TAG) + '\n')
            output.write("export " + str(GPU_TAG) + '\n')


builder = MosaicDockerBuild()
builder.build()
